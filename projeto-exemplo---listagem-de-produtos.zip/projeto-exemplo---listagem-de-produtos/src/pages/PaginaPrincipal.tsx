import React from 'react';
import { View, Text, StatusBar, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { Button } from '../components/Button';

export function PaginaPrincipal({ navigation }: { navigation: any }){

    function proximaTela(){
        navigation.navigate('ListagemProdutos');
    }

    return (
        <View style={styles.container}>
            <StatusBar
                backgroundColor="#32B768"
                barStyle='default' // altera a cor do texto contido no StatusBar: default, dark-content, light-content
            />

            <View style={styles.homeView}>
                <Text style={{fontSize: 32}}>Home Page</Text>
            </View>

            <Button 
                title="Listagem de Produtos" 
                onPress={proximaTela}
            />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center'
    },
    homeView: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-around'
    }
});