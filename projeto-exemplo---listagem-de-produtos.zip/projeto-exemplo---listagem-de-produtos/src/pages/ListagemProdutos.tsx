import React, { useEffect, useState } from 'react';
import { View, StatusBar, StyleSheet, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import { ProductCard } from '../components/ProductCard';
import { Button } from '../components/Button';

// importe e configure o axios
import axios from 'axios';
axios.defaults.baseURL = 'http://10.140.20.11:4444';

interface Response {
  codigo: number;
  nome: string;
}

export function ListagemProdutos({ navigation }: { navigation: any }) {
  // informe os useStates
  const [response, setResponse] = useState<Response[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [load, setLoad] = useState(true);

  // crie a função listarProdutos
  const listarProdutos = async () => {
    setLoading(true);
    try {
      const res = await axios.get('/produtos');
      setResponse(res.data);
      setError('');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };
  // crie o useEffect
  useEffect(() => {
    navigation.addListener('focus', () => {
      setLoad(!load);
    });
    listarProdutos();
  }, [load, navigation]);
  function proximaTela() {
    navigation.navigate('CadProduto', { codigoProduto: 0 });
  }

  function excluirProduto(codigo: number) {
    Alert.alert(
        "Confirmação",
        `Deseja realmente excluir o produto de código ${codigo}`,
        [
          {
            text: "Sim",
            onPress: () => {
              axios.delete(`produtos/${codigo}`);
              setLoad(!load);
              Alert.alert("Produto excluído com sucesso!");

            },
            style: 'default'
          },
          {
            text: "Não",
            style: 'default'
          }
        ]
    );

  }

  function editarProduto(codigo: number) {
    navigation.navigate('CadProduto', {codigoProduto: codigo});
    
  }

  return (
    <View style={styles.container}>
      <StatusBar />
      <View style={styles.viewList}>
        {response.map((produto) => (
          <ProductCard
            key={String(produto.codigo)}
            codigo={produto.codigo}
            nome={produto.nome}
            editarProduto={() => editarProduto(produto.codigo)}
            excluirProduto={() => excluirProduto(produto.codigo)}
          />
        ))}
      </View>

      <View style={styles.viewFooter}>
        <Button title="Cadastrar Produtos" onPress={proximaTela} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
  },
  viewList: {
    padding: 5,
  },
  viewFooter: {
    alignItems: 'center',
  },
});
