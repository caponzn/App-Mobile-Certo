import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import { Button } from '../components/Button';

import axios from 'axios';

axios.defaults.baseURL = 'http://10.140.20.11:4444';

export function CadProduto({ navigation, route }: { navigation: any, route : any }){
    const [nome, setNome] = useState("");
    const [descricao, setDescricao] = useState("");
    const [preco, setPreco] = useState(0.00);
    const [quantidade, setQuantidade] = useState(1);

    useEffect(() => {
      async function buscarProduto(codigo: number){
        try {
          alert("Buscando Produto");
          const response = await axios.get(`/produtos/${codigo}`);
          setNome(response.data.nome);
          setDescricao(response.data.descricao);
          setQuantidade(response.data.quantidade);
          setPreco(response.data.preco);
        } catch (err) {
          console.log(err);
        }
      }
      const codigo = route.params.codigoProduto;
      if(codigo != 0)
        buscarProduto(codigo);      
    }, []);

    async function cadastrarProduto(){
      const produto = {
          nome,
          descricao,          
          preco,
          quantidade
      };

     try {
        if(route.params.codigoProduto == 0){
          await axios.post('/produtos', produto);
          alert("Produto Salvo com Sucesso!!!");
        } else {
          await axios.put(`/produtos/${route.params.codigoProduto}`,
produto);
          alert("Produto Atualizado com Sucesso!!!");
        }
      } catch (err) {
        console.log(err);
      }
      navigation.navigate('PaginaPrincipal');
    }
    

    return ( 
        <SafeAreaView style={styles.container}>
            <StatusBar />

            <View style={styles.viewForm}>
                <View style={styles.viewInput}>
                    <Text style={styles.titleInput}>
                        Nome do Produto
                    </Text>

                    <TextInput 
                        style={styles.input}
                        placeholder="Digite o nome do produto"
                        defaultValue={nome}
                        keyboardType="default"
                        onChangeText={valor => setNome(String(valor))}
                    />
                </View>

                <View style={styles.viewInput}>
                    <Text style={styles.titleInput}>
                        Descrição
                    </Text>

                    <TextInput 
                        style={styles.input}
                        placeholder="Digite o nome do fornecedor"
                        defaultValue={descricao}
                        keyboardType="default"
                        onChangeText={valor => setDescricao(String(valor))}
                    />
                </View>

                <View style={styles.viewInput}>
                    <Text style={styles.titleInput}>
                        Preço Unitário
                    </Text>

                    <TextInput 
                        style={styles.input}
                        placeholder="Digite o preço unitário"
                        defaultValue={String(preco)}
                        keyboardType="numeric"
                        onChangeText={valor => setPreco(Number(valor))}
                    />
                </View>

                <View style={styles.viewInput}>
                    <Text style={styles.titleInput}>
                        Estoque
                    </Text>

                    <TextInput 
                        style={styles.input}
                        placeholder="Digite a quantidade do produto"
                        defaultValue={String(quantidade)}
                        keyboardType="numeric"
                        onChangeText={valor => setQuantidade(Number(valor))}
                    />
                </View>
            </View>

            <View style={styles.viewFooter}>
                <Button 
                    title="Salvar"    
                    onPress={() => cadastrarProduto()}            
                />
            </View>           

        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'space-between'
    },
    viewForm: {

    },
    viewInput: {
        paddingHorizontal: 10,
        paddingVertical: 5
    },
    titleInput: {
        fontSize: 14,
        marginLeft: 4,
        marginBottom: 2
    },
    input: {
        height: 56,
        paddingLeft: 10,
        borderWidth: 2,
        borderColor: '#0000001F',
        backgroundColor: '#FFFFFF',
        borderRadius: 8,
        fontSize: 16
    },
    viewFooter: {
        alignItems: 'center'
    }    
});