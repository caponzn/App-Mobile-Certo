import React from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

import { Button } from '../components/Button';

import logoImg from '../assets/Logo.png';

export function BoasVindas({ navigation }: { navigation: any }) {

    function proximaTela(){
        navigation.navigate('PaginaPrincipal')
    }

    return (
        <View style={styles.container}> 
            <Text style={styles.title}>
                Programação para {'\n'}
                Dispositivos Móveis
            </Text>
            <Image
                source={logoImg}
                style={styles.image}
            />
            <Text style={styles.subtitle}>
                Aplicativo exemplo usado durante a aula {'\n'}
                de Programação para Dispositivos Móveis
            </Text>
            <Button 
                title="Iniciar" 
                onPress={proximaTela}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#FFFFFF'
    },
    title: {
        fontSize: 32,
        textAlign: 'center',
        marginTop: 38,
        color: '#52665A',
        fontFamily: 'Jost_600SemiBold'
    },
    image: {
        width: 166,
        height: 200
    },
    subtitle: {
        textAlign: 'center',
        fontSize: 17,
        paddingHorizontal: 20,
        color: '#52665A',
        fontFamily: 'Jost_400Regular'
    }
});