-- SQLite
CREATE TABLE produto(
    codigo INTEGER PRIMARY KEY,
    nome TEXT NOT NULL,
    descricao TEXT NOT NULL,
    quantidade NUMERIC NOT NULL,
    preco NUMERIC NOT NULL
);