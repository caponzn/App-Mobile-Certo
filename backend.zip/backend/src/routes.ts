import express, { json, response } from 'express';
import knex from './database/conection';
const routes = express.Router();

routes.get('/users', (request, response)=> {
    console.log('Hellow world');
    response.json([
        'Douglas',
        'Costas',
        'Alexandro', 
        'Claudio',
        'Pedro',
        'Mbape'
    ]);
});
routes.post('/produtos', async (req, res) => {
    const {
        nome,
        descricao,
        quantidade,
        preco
    } = req.body;
    const produto  = {
        nome,
        descricao,
        quantidade,
        preco
    };
    const insertedIds = await knex('produto').insert(produto);
    const produto_id = insertedIds[0];
    return res.json({
        id:produto_id,
        ...produto
    });
});
routes.get('/produtos', async (req, res) => {
    const produtos = await knex('produto')
        .select('produto.codigo', 'produto.nome')
        .orderBy('produto.nome');

    return res.json(produtos);
});
routes.get('/produtos/:codigo', async (req, res) => {
    const {codigo} = req.params;

    const produtos = await knex('produto')
        .select('produto.*')
        .where('produto.codigo', codigo)
        .first();

    return res.json(produtos);
});

routes.delete('/produtos/deletar/:codigo', async (req, res)=>{
    const {codigo} = req.params;

    await knex('produto')
        .delete()
        .where('produto.codigo',codigo)
    console.log("Deletado")
    return  res.json({
        status: 'sucess',
        
    });
});
routes.put('/produtos/:codigo', async (req, res) => {
    const {codigo} = req.params;

    const {
        nome,
        descricao,
        quantidade,
        preco
    } = req.body;

    const produto  = {
        nome,
        descricao,
        quantidade,
        preco
    }

    await knex('produto')
    .update(produto)
    .where('codigo', codigo);
    
    return res.json({
        status: 'sucess',
        data: produto
    });
});

export default routes;