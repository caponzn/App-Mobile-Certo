import express, { response } from 'express';
import routes from './routes';
const app = express();

app.use(express.json());
app.use(routes);

app.listen(4444);
console.log("Serve On-Line em 4444")